#ifndef MVDG_H
#define MVDG_H

////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2016, 2019, 2022 Qualcomm Technologies, Inc.
// All Rights Reserved.
// Confidential and Proprietary - Qualcomm Technologies, Inc.
////////////////////////////////////////////////////////////////////////////////

#include "mvDGCommon26.h"
#include "mvDGIP.h"
#include "mvDGTC26.h"

#endif
