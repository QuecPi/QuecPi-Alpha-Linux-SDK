<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="ja_JP">
<context>
    <name>main</name>
    <message>
        <location filename="../main.qml" line="8"/>
        <source>Hello World</source>
        <translation>こんにちは世界</translation>
    </message>
    <message>
        <location filename="../main.qml" line="12"/>
        <source>Hello Text</source>
        <translation>ハローテキスト</translation>
    </message>
    <message>
        <location filename="../main.qml" line="35"/>
        <source>Hello</source>
        <translation>こんにちは</translation>
    </message>
    <message>
        <location filename="../main.qml" line="38"/>
        <source>ListView</source>
        <translation>リストビュー</translation>
    </message>
</context>
</TS>

