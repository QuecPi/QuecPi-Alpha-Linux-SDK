The scalable icons are from:

http://tango.freedesktop.org/Tango_Icon_Library
http://darkobra.deviantart.com/art/Tango-Weather-Icon-Pack-98024429

